# NEAS AI Workforce · Operational Control Plane (improved)

CEO / CAIO multi-agent directory, work queue, approval center + audit history on Supabase.

## What was improved vs the broken state

- **Graceful `connection-required` mode**: missing `SUPABASE_SECRET_KEY` no longer blanks the UI. You get a banner, live diagnostics (`/api/health`), and seeded preview data (90-agent shape) so ops can continue.
- **Server-only secret discipline**: secret read exclusively in `lib/env.ts` + `lib/supabaseServer.ts` (API routes / server). Browser uses only `NEXT_PUBLIC_SUPABASE_URL` + `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Health API returns booleans, never key material, and warns on `NEXT_PUBLIC_*SECRET*` leaks.
- **Actionable Vercel fix in-product**: the banner lists exact Dashboard clicks + redeploy requirement.
- **Idempotent SQL**: `supabase/schema.sql` (RLS, public-read / service-write) + `supabase/seed-90-agents.sql` (exactly NEAS-001…090, re-runnable).
- **Approvals persist + audit**: POST `/api/approvals` writes status + `audit_log` row when live; acknowledges locally when in demo.

## Env (Vercel → Project → Settings → Environment Variables)

| Var | Where | Envs |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | public | Production, Preview |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | public | Production, Preview |
| `SUPABASE_SECRET_KEY` | **server-only** | **Production + Preview** |

Never create `NEXT_PUBLIC_SUPABASE_SECRET_KEY`. After saving: **Deployments → Redeploy**.

## Run

```bash
npm install
npm run dev
# provision Supabase: run supabase/schema.sql, then supabase/seed-90-agents.sql in SQL Editor
```

## Routes

- `/` control plane
- `GET /api/health` — `{ mode: live|degraded|connection-required, checks, guidance }`
- `GET /api/agents|tasks|approvals|audit` — live rows or demo fallback with `mode`
- `POST /api/approvals` `{ id, decision: approved|rejected, actor }`

## RBAC — CEO / CAIO approvals (v2.1)

Policy (`lib/rbac.ts`, enforced server-side in `POST /api/approvals`):

| Risk | May finalize |
|---|---|
| low / medium / high | CEO, CAIO |
| critical | CEO only |
| any | Operator: read/request only, no approve/reject |
| any | Requester cannot self-approve (separation of duties) |

Denied attempts return 403 + are written to `audit_log` (`approval.*.denied` with `actor_role`).
UI has an Acting-as switch (CEO/CAIO/Operator, localStorage), per-card lock reasons, and actionable counts.

Run `supabase/migration-rbac.sql` once to add `required_role`, `decided_by_role`, `decision_reason`, `actor_role`.

## Auth — JWT is the authority (v2.2)

`actorRole` no longer comes from the UI. Flow:

1. User signs in via Supabase Auth (email/password, client `browserSupabase()`).
2. Client sends `Authorization: Bearer <access_token>` to `POST /api/approvals`, `GET /api/auth/me`, `POST /api/admin/set-role`.
3. Server verifies JWT with `auth.getUser(token)` (`lib/auth.ts`), derives role from `app_metadata.exec_role` → `profiles.exec_role` → `Operator` (least privilege). Body `previewRole` is **ignored when live** (demo-only).
4. RBAC + separation-of-duties enforced, denials audit-logged with `actor_role`.

Setup:
- Supabase Auth → enable Email provider.
- Run `supabase/migration-auth.sql` (profiles table).
- First CEO: `update auth.users set raw_app_meta_data = raw_app_meta_data || '{"exec_role":"CEO"}' where email='you@...'` → sign out/in → verify via `GET /api/auth/me`.
- CEOs assign further roles from the UI (target UUID + role) or via `POST /api/admin/set-role`.
- Unauthenticated users: approvals disabled when live; preview selector works in demo only and responses carry `untrustedPreview: true`.

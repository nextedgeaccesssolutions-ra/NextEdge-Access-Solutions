export type ConnectionStatus = "live" | "degraded" | "down";

export type ExecRole = "CEO" | "CAIO" | "Operator";

export interface AgentProfile {
  id: string;
  codename: string;
  role: string;
  division: "CEO Office" | "CAIO Office" | "Operations" | "Intelligence" | "Autonomy";
  capabilities: string[];
  status: "active" | "standby" | "training" | "offline";
  autonomy_level: number;
  current_load: number;
  last_heartbeat: string;
}

export interface WorkItem {
  id: string;
  title: string;
  owner_agent: string;
  priority: "P0" | "P1" | "P2" | "P3";
  status: "queued" | "in_progress" | "blocked" | "done";
  eta: string;
  progress: number;
}

export interface Approval {
  id: string;
  subject: string;
  requested_by: string;
  risk: "low" | "medium" | "high" | "critical";
  status: "pending" | "approved" | "rejected";
  created_at: string;
  detail: string;
  required_role?: string;
  decided_by?: string | null;
  decided_by_role?: ExecRole | string | null;
  decided_at?: string | null;
}

export interface AuditEvent {
  id: string;
  at: string;
  actor: string;
  actor_role?: string | null;
  action: string;
  target: string;
  hash: string;
}

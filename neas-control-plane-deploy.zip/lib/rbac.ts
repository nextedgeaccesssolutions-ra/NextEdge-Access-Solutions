export type ExecRole = "CEO" | "CAIO" | "Operator";
export type Risk = "low" | "medium" | "high" | "critical";

export const ROLES: ExecRole[] = ["CEO", "CAIO", "Operator"];

// Who may finalize each risk tier. Critical = CEO only (dual-control ready).
export const APPROVAL_POLICY: Record<Risk, ExecRole[]> = {
  low: ["CEO", "CAIO"],
  medium: ["CEO", "CAIO"],
  high: ["CEO", "CAIO"],
  critical: ["CEO"],
};

export function requiredRoles(risk: Risk): ExecRole[] {
  return APPROVAL_POLICY[risk] ?? ["CEO"];
}

export function canDecide(role: ExecRole, risk: Risk): boolean {
  return requiredRoles(risk).includes(role);
}

export interface DecideCheck {
  allowed: boolean;
  reason: string;
}

// Separation of duties: requester cannot finalize own request.
export function checkDecide(opts: {
  actorRole: ExecRole;
  actorId: string;
  risk: Risk;
  requestedBy: string;
  status: string;
}): DecideCheck {
  if (opts.status !== "pending")
    return { allowed: false, reason: `Already ${opts.status} — decision is final.` };
  if (!canDecide(opts.actorRole, opts.risk))
    return {
      allowed: false,
      reason:
        opts.risk === "critical"
          ? "Critical risk requires CEO. CAIO/Operator cannot finalize."
          : `${opts.risk} risk requires ${requiredRoles(opts.risk).join(" or ")}.`,
    };
  if (opts.actorRole === "Operator")
    return { allowed: false, reason: "Operators can request but cannot approve/reject." };
  if (opts.actorId && opts.requestedBy && opts.actorId === opts.requestedBy)
    return { allowed: false, reason: "Separation of duties: requester cannot self-approve." };
  return { allowed: true, reason: "Authorized." };
}

export function roleBlurb(role: ExecRole): string {
  if (role === "CEO") return "Full authority — all tiers including critical.";
  if (role === "CAIO") return "Low / medium / high. Critical is CEO-only.";
  return "Read + request. No approve/reject.";
}

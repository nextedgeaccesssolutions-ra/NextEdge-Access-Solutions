// Server-only env resolution. Never import this from client components.
export function getServerEnv() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
  // Accept either name, prefer SUPABASE_SECRET_KEY. Never accept a NEXT_PUBLIC secret.
  const secret = process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
  const leakedPublicSecret =
    (process.env.NEXT_PUBLIC_SUPABASE_SECRET_KEY ?? "") !== "" ||
    (process.env.NEXT_PUBLIC_SUPABASE_SERVICE_ROLE_KEY ?? "") !== "";
  return {
    url,
    secret,
    anon,
    hasUrl: url.startsWith("https://"),
    hasSecret: secret.length > 40,
    hasAnon: anon.length > 40,
    leakedPublicSecret,
    secretSource:
      (process.env.SUPABASE_SECRET_KEY ? "SUPABASE_SECRET_KEY" : null) ??
      (process.env.SUPABASE_SERVICE_ROLE_KEY ? "SUPABASE_SERVICE_ROLE_KEY" : null) ??
      "none",
  };
}

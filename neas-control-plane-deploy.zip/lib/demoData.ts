import type { AgentProfile, Approval, AuditEvent, WorkItem } from "./types";

const DIVISIONS = ["CEO Office", "CAIO Office", "Operations", "Intelligence", "Autonomy"] as const;
const ROLES = ["Strategist","Orchestrator","Analyst","Operator","Guardian","Scout","Synthesizer","Auditor","Planner","Executor"];
const CAPS = ["planning","research","triage","forecasting","compliance","routing","summarization","verification","scheduling","escalation"];

function seeded(i: number) {
  const x = Math.sin(i * 999.7) * 10000;
  return x - Math.floor(x);
}

export function demoAgents(count = 90): AgentProfile[] {
  return Array.from({ length: count }, (_, k) => {
    const i = k + 1;
    const statuses: AgentProfile["status"][] = ["active","active","active","standby","training","offline"];
    return {
      id: `NEAS-${String(i).padStart(3, "0")}`,
      codename: `Agent ${ROLES[i % ROLES.length]}-${String(i).padStart(2, "0")}`,
      role: ROLES[i % ROLES.length],
      division: DIVISIONS[i % DIVISIONS.length],
      capabilities: [CAPS[i % CAPS.length], CAPS[(i + 3) % CAPS.length], CAPS[(i + 6) % CAPS.length]],
      status: statuses[i % statuses.length],
      autonomy_level: 1 + Math.floor(seeded(i) * 5),
      current_load: Math.floor(seeded(i * 7) * 100),
      last_heartbeat: new Date(Date.now() - Math.floor(seeded(i * 13) * 600000)).toISOString(),
    };
  });
}

export function demoTasks(): WorkItem[] {
  const owners = ["NEAS-001","NEAS-007","NEAS-012","NEAS-023","NEAS-031","NEAS-045","NEAS-058","NEAS-072","NEAS-089"];
  const titles = ["Nightly revenue reconciliation","Churn-risk triage sweep","Vendor SLA compliance check","Exec briefing synthesis","Anomaly review: auth latency","Forecast refresh: APAC pipeline","Policy update propagation","Queue rebalancing","Audit packet assembly"];
  return titles.map((title, i) => ({
    id: `WQ-${2400 + i}`,
    title,
    owner_agent: owners[i % owners.length],
    priority: (["P0","P1","P1","P2","P2","P3"] as const)[i % 6],
    status: (["in_progress","queued","queued","blocked","in_progress","done"] as const)[i % 6],
    eta: new Date(Date.now() + (i + 1) * 3600000 * 3).toISOString(),
    progress: [68, 12, 0, 41, 83, 100][i % 6],
  }));
}

export function demoApprovals(): Approval[] {
  return [
    { id: "APR-901", subject: "Autonomy raise L3 → L4 for NEAS-023", requested_by: "NEAS-007", risk: "high", status: "pending", created_at: new Date(Date.now()-42*60000).toISOString(), detail: "Expand tool scope to billing refunds ≤ ₱5,000 with dual-verify.", required_role: "CEO or CAIO" },
    { id: "APR-902", subject: "Publish exec briefing to #leadership", requested_by: "NEAS-012", risk: "medium", status: "pending", created_at: new Date(Date.now()-95*60000).toISOString(), detail: "Contains revenue + churn deltas. PII scrubbed.", required_role: "CEO or CAIO" },
    { id: "APR-903", subject: "Auto-remediate blocked queue WQ-2403", requested_by: "NEAS-031", risk: "critical", status: "pending", created_at: new Date(Date.now()-130*60000).toISOString(), detail: "Requires production write. Human sign-off mandatory.", required_role: "CEO only" },
    { id: "APR-894", subject: "Rotate vendor API credentials", requested_by: "NEAS-045", risk: "low", status: "approved", created_at: new Date(Date.now()-26*3600000).toISOString(), detail: "Routine rotation, zero downtime path verified.", required_role: "CEO or CAIO", decided_by: "CAIO", decided_by_role: "CAIO" },
  ];
}

export function demoAudit(): AuditEvent[] {
  const acts = ["heartbeat","task.assign","approval.request","policy.sync","queue.rebalance","briefing.publish","access.grant"];
  return Array.from({ length: 14 }, (_, i) => ({
    id: `EVT-${7700 - i}`,
    at: new Date(Date.now() - i * 11 * 60000).toISOString(),
    actor: `NEAS-${String(1 + ((i * 7) % 90)).padStart(3, "0")}`,
    actor_role: i % 4 === 0 ? "CEO" : i % 4 === 1 ? "CAIO" : "Operator",
    action: acts[i % acts.length],
    target: i % 3 === 0 ? `WQ-${2400 + (i % 9)}` : `APR-${900 + (i % 5)}`,
    hash: `sha:${(i * 2654435761 % 16777216).toString(16).padStart(6, "0")}…`,
  }));
}

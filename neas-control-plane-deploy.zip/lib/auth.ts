// Server-only: derive the authoritative exec role from the Supabase JWT.
// Priority: app_metadata.exec_role → profiles.exec_role → Operator (least privilege).
import { createClient } from "@supabase/supabase-js";
import { getServerEnv } from "./env";
import { getServiceClient } from "./supabaseServer";
import type { ExecRole } from "./rbac";

function asRole(v: unknown): ExecRole | null {
  return v === "CEO" || v === "CAIO" || v === "Operator" ? v : null;
}

export interface AuthContext {
  userId: string;
  email: string;
  role: ExecRole;
  source: "app_metadata" | "profiles" | "default";
}

export function bearerToken(req: Request): string | null {
  const h = req.headers.get("authorization") ?? "";
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m ? m[1].trim() : null;
}

export async function authFromJWT(req: Request): Promise<{ ctx: AuthContext } | { error: string; status: number }> {
  const { url, anon } = getServerEnv();
  const token = bearerToken(req);
  if (!url.startsWith("https://") || anon.length < 40)
    return { error: "Auth not configured (missing URL/anon key).", status: 501 };
  if (!token) return { error: "Sign in required — no access token.", status: 401 };

  // Verify JWT with Supabase (never trust client-supplied role).
  const anonClient = createClient(url, anon, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data, error } = await anonClient.auth.getUser(token);
  if (error || !data.user) return { error: "Invalid or expired session. Sign in again.", status: 401 };
  const u = data.user;

  const metaRole = asRole((u.app_metadata as any)?.exec_role);
  if (metaRole) {
    return { ctx: { userId: u.id, email: u.email ?? u.id, role: metaRole, source: "app_metadata" } };
  }
  // Fallback: profiles table (service-role read).
  const sb = getServiceClient();
  if (sb) {
    const { data: prof } = await sb.from("profiles").select("exec_role").eq("id", u.id).maybeSingle();
    const pRole = asRole((prof as any)?.exec_role);
    if (pRole) return { ctx: { userId: u.id, email: u.email ?? u.id, role: pRole, source: "profiles" } };
  }
  return { ctx: { userId: u.id, email: u.email ?? u.id, role: "Operator", source: "default" } };
}

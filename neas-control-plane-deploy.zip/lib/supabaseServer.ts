import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { getServerEnv } from "./env";

// Singleton for server routes. Service-role key NEVER leaves the server.
let cached: SupabaseClient | null = null;

export function getServiceClient(): SupabaseClient | null {
  const { url, secret } = getServerEnv();
  if (!url.startsWith("https://") || secret.length < 40) return null;
  if (cached) return cached;
  cached = createClient(url, secret, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { "x-client": "neas-control-plane/server" } },
  });
  return cached;
}

export async function probeSupabase(): Promise<{
  reachable: boolean;
  agentsCount: number | null;
  error?: string;
}> {
  const sb = getServiceClient();
  if (!sb) return { reachable: false, agentsCount: null, error: "missing-env" };
  try {
    const { count, error } = await sb.from("agents").select("id", { count: "exact", head: true });
    if (error) return { reachable: false, agentsCount: null, error: error.message.slice(0, 220) };
    return { reachable: true, agentsCount: count ?? null };
  } catch (e: any) {
    return { reachable: false, agentsCount: null, error: String(e?.message ?? e).slice(0, 220) };
  }
}

import "./globals.css";

export const metadata = {
  title: "NEAS AI Workforce · Operational Control Plane",
  description: "CEO / CAIO multi-agent directory, work queue, approvals and audit.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

import { NextResponse } from "next/server";
import { getServiceClient } from "../../../lib/supabaseServer";
import { demoAgents } from "../../../lib/demoData";

export const dynamic = "force-dynamic";

export async function GET() {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ mode: "demo", data: demoAgents(90), note: "SUPABASE_SECRET_KEY missing — showing seeded directory preview." });
  const { data, error } = await sb.from("agents").select("*").order("id").limit(200);
  if (error) return NextResponse.json({ mode: "demo", data: demoAgents(90), note: error.message }, { status: 200 });
  return NextResponse.json({ mode: "live", data });
}

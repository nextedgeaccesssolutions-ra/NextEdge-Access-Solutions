import { NextResponse } from "next/server";
import { authFromJWT } from "../../../../lib/auth";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const res = await authFromJWT(req);
  if ("error" in res) return NextResponse.json({ authenticated: false, error: res.error }, { status: res.status });
  return NextResponse.json({ authenticated: true, ...res.ctx });
}

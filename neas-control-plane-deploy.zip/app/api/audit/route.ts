import { NextResponse } from "next/server";
import { getServiceClient } from "../../../lib/supabaseServer";
import { demoAudit } from "../../../lib/demoData";

export const dynamic = "force-dynamic";

export async function GET() {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ mode: "demo", data: demoAudit() });
  const { data, error } = await sb.from("audit_log").select("*").order("at", { ascending: false }).limit(100);
  if (error) return NextResponse.json({ mode: "demo", data: demoAudit(), note: error.message });
  return NextResponse.json({ mode: "live", data });
}

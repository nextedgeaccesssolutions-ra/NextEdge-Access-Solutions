import { NextResponse } from "next/server";
import { getServerEnv } from "../../../lib/env";
import { probeSupabase } from "../../../lib/supabaseServer";

export const dynamic = "force-dynamic";

export async function GET() {
  const env = getServerEnv();
  const configured = env.hasUrl && env.hasSecret;
  const probe = await probeSupabase();

  // Never return key material. Booleans only.
  return NextResponse.json({
    ok: configured && probe.reachable && !env.leakedPublicSecret,
    mode: !configured ? "connection-required" : probe.reachable ? "live" : "degraded",
    checks: {
      urlPresent: env.hasUrl,
      secretPresent: env.hasSecret,
      secretSource: env.secretSource,
      anonPresent: env.hasAnon,
      leakedPublicSecret: env.leakedPublicSecret,
      reachable: probe.reachable,
      agentsCount: probe.agentsCount,
      probeError: probe.error ?? null,
    },
    guidance: !configured
      ? "Add SUPABASE_SECRET_KEY to Vercel Production + Preview (server-only). Redeploy. Do not use NEXT_PUBLIC."
      : probe.reachable
        ? "Connected. Service-role key stays server-only."
        : `Server key present but query failed: ${probe.error ?? "unknown"}. Verify tables exist (see supabase/schema.sql).`,
    at: new Date().toISOString(),
  });
}

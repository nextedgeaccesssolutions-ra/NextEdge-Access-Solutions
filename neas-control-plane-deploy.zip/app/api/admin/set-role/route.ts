import { NextResponse } from "next/server";
import { authFromJWT } from "../../../../lib/auth";
import { getServiceClient } from "../../../../lib/supabaseServer";
export const dynamic = "force-dynamic";
function valid(v: unknown) { return v === "CEO" || v === "CAIO" || v === "Operator"; }
export async function POST(req: Request) {
  const auth = await authFromJWT(req);
  if ("error" in auth) return NextResponse.json({ error: auth.error }, { status: auth.status });
  const body = await req.json().catch(() => ({}));
  const { targetUserId, exec_role } = body as { targetUserId: string; exec_role: string };
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ error: "Server secret not configured." }, { status: 500 });
  if (!targetUserId || !valid(exec_role)) return NextResponse.json({ error: "targetUserId + exec_role (CEO|CAIO|Operator) required." }, { status: 400 });
  const isSelf = targetUserId === auth.ctx.userId;
  const callerIsCEO = auth.ctx.role === "CEO";
  let ceoCount = 1;
  try {
    const { data } = await sb.from("profiles").select("id").eq("exec_role", "CEO").limit(2);
    ceoCount = data?.length ?? 1;
  } catch {}
  if (!callerIsCEO && !(isSelf && ceoCount === 0))
    return NextResponse.json({ error: "Only CEO can assign roles.", required: ["CEO"] }, { status: 403 });
  const { error: adminErr } = await sb.auth.admin.updateUserById(targetUserId, { app_metadata: { exec_role } });
  if (adminErr) return NextResponse.json({ error: adminErr.message }, { status: 500 });
  await sb.from("profiles").upsert({ id: targetUserId, exec_role }, { onConflict: "id" });
  await sb.from("audit_log").insert({ actor: auth.ctx.email, actor_role: auth.ctx.role, action: `role.assign:${exec_role}`, target: targetUserId });
  return NextResponse.json({ ok: true, targetUserId, exec_role });
}

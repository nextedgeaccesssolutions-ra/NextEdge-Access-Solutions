import { NextResponse } from "next/server";
import { getServiceClient } from "../../../lib/supabaseServer";
import { demoTasks } from "../../../lib/demoData";

export const dynamic = "force-dynamic";

export async function GET() {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ mode: "demo", data: demoTasks() });
  const { data, error } = await sb.from("work_queue").select("*").order("created_at", { ascending: false }).limit(100);
  if (error) return NextResponse.json({ mode: "demo", data: demoTasks(), note: error.message });
  return NextResponse.json({ mode: "live", data });
}

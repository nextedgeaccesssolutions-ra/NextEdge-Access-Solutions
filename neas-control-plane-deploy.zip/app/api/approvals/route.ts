import { NextResponse } from "next/server";
import { getServiceClient } from "../../../lib/supabaseServer";
import { demoApprovals } from "../../../lib/demoData";
import { authFromJWT } from "../../../lib/auth";
import { checkDecide } from "../../../lib/rbac";

export const dynamic = "force-dynamic";

export async function GET() {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ mode: "demo", data: demoApprovals() });
  const { data, error } = await sb.from("approvals").select("*").order("created_at", { ascending: false }).limit(100);
  if (error) return NextResponse.json({ mode: "demo", data: demoApprovals(), note: error.message });
  return NextResponse.json({ mode: "live", data });
}

export async function POST(req: Request) {
  const sb = getServiceClient();
  const body = await req.json().catch(() => ({}));
  const { id, decision, reason } = body as { id: string; decision: "approved" | "rejected"; reason?: string };
  if (!id || !["approved", "rejected"].includes(decision)) {
    return NextResponse.json({ error: "id + decision (approved|rejected) required" }, { status: 400 });
  }

  // ── Demo (no server secret): preview RBAC using caller-selected preview role ──
  if (!sb) {
    const previewRole = body.previewRole === "CEO" || body.previewRole === "CAIO" ? body.previewRole : "Operator";
    const demo = demoApprovals().find((a) => a.id === id);
    if (!demo) return NextResponse.json({ error: `Approval ${id} not found (demo).` }, { status: 404 });
    const chk = checkDecide({ actorRole: previewRole, actorId: "preview", risk: demo.risk, requestedBy: demo.requested_by, status: demo.status });
    if (!chk.allowed) return NextResponse.json({ error: `[preview] ${chk.reason}`, required: demo.risk === "critical" ? ["CEO"] : ["CEO", "CAIO"] }, { status: 403 });
    return NextResponse.json({ mode: "demo", id, decision, actorRole: previewRole, untrustedPreview: true, message: `Preview as ${previewRole} (demo). Sign in with Supabase Auth for authoritative decisions.` });
  }

  // ── Live: role comes ONLY from the verified JWT. Body role is ignored. ──
  const auth = await authFromJWT(req);
  if ("error" in auth) return NextResponse.json({ error: auth.error }, { status: auth.status });
  const { userId, email, role } = auth.ctx;

  const { data, error } = await sb.from("approvals").select("risk,requested_by,status").eq("id", id).maybeSingle();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  if (!data) return NextResponse.json({ error: `Approval ${id} not found.` }, { status: 404 });

  const check = checkDecide({ actorRole: role, actorId: email, risk: data.risk, requestedBy: data.requested_by, status: data.status });
  // Also block self-approval by user id (in case requested_by stores an email/uid).
  const selfById = userId && (data.requested_by === userId || data.requested_by === email);
  if (selfById) {
    await sb.from("audit_log").insert({ actor: email, actor_role: role, action: `approval.${decision}.denied`, target: id });
    return NextResponse.json({ error: "Separation of duties: requester cannot self-approve." }, { status: 403 });
  }
  if (!check.allowed) {
    await sb.from("audit_log").insert({ actor: email, actor_role: role, action: `approval.${decision}.denied`, target: id });
    return NextResponse.json({ error: check.reason, required: data.risk === "critical" ? ["CEO"] : ["CEO", "CAIO"], actorRole: role }, { status: 403 });
  }

  const { error: upErr } = await sb.from("approvals").update({
    status: decision, decided_by: email, decided_by_role: role,
    decided_at: new Date().toISOString(),
    decision_reason: (reason ?? "").toString().slice(0, 500),
  }).eq("id", id);
  if (upErr) return NextResponse.json({ error: upErr.message }, { status: 500 });
  await sb.from("audit_log").insert({ actor: email, actor_role: role, action: `approval.${decision}`, target: id });
  return NextResponse.json({ mode: "live", id, decision, actorRole: role });
}

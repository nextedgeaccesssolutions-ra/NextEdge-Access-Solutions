"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { AgentProfile, Approval, AuditEvent, WorkItem, ExecRole } from "../lib/types";
import { checkDecide, roleBlurb } from "../lib/rbac";
import { browserSupabase } from "../lib/supabaseClient";

type Tab = "directory" | "queue" | "approvals" | "audit";
interface Health {
  ok: boolean; mode: string;
  checks: { urlPresent: boolean; secretPresent: boolean; secretSource: string; anonPresent: boolean; leakedPublicSecret: boolean; reachable: boolean; agentsCount: number | null; probeError: string | null; };
  guidance: string; at: string;
}
interface Me { authenticated: boolean; userId?: string; email?: string; role?: ExecRole; source?: string; error?: string }

async function j<T>(u: string, init?: RequestInit): Promise<T> {
  const r = await fetch(u, { cache: "no-store", ...init });
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((body as any).error ?? `Request failed (${r.status})`);
  return body as T;
}

export default function Page() {
  const [health, setHealth] = useState<Health | null>(null);
  const [agents, setAgents] = useState<AgentProfile[]>([]);
  const [tasks, setTasks] = useState<WorkItem[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [modes, setModes] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("approvals");
  const [q, setQ] = useState("");
  const [div, setDiv] = useState("all");
  const [acting, setActing] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // ── Auth (JWT is the authority) ──
  const [me, setMe] = useState<Me | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [previewRole, setPreviewRole] = useState<ExecRole>("CAIO");
  const [targetUid, setTargetUid] = useState("");
  const [targetRole, setTargetRole] = useState<ExecRole>("Operator");

  const refreshMe = useCallback(async () => {
    try {
      const sb = browserSupabase();
      const { data } = await sb.auth.getSession();
      const token = data.session?.access_token;
      if (!token) { setMe({ authenticated: false }); return null; }
      const m = await j<Me>("/api/auth/me", { headers: { Authorization: `Bearer ${token}` } });
      setMe(m);
      return m;
    } catch { setMe({ authenticated: false }); return null; }
  }, []);

  useEffect(() => {
    const sb = browserSupabase();
    refreshMe();
    const { data: sub } = sb.auth.onAuthStateChange(() => refreshMe());
    return () => sub.subscription.unsubscribe();
  }, [refreshMe]);

  const verifiedRole: ExecRole | null = me?.authenticated ? (me.role ?? "Operator") : null;

  async function signIn() {
    setAuthBusy(true); setErr(null);
    try {
      const sb = browserSupabase();
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await refreshMe(); await refresh();
    } catch (e: any) { setErr(e.message); } finally { setAuthBusy(false); }
  }
  async function signUp() {
    setAuthBusy(true); setErr(null);
    try {
      const sb = browserSupabase();
      const { error } = await sb.auth.signUp({ email, password });
      if (error) throw error;
      await refreshMe();
      setErr("Account created — check email confirmation if required, then Sign in.");
    } catch (e: any) { setErr(e.message); } finally { setAuthBusy(false); }
  }
  async function signOut() {
    await browserSupabase().auth.signOut();
    setMe({ authenticated: false });
  }
  async function assignRole() {
    setErr(null);
    try {
      const sb = browserSupabase();
      const { data } = await sb.auth.getSession();
      const token = data.session?.access_token;
      await j("/api/admin/set-role", { method: "POST", headers: { "content-type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ targetUserId: targetUid, exec_role: targetRole }) });
      setErr(`Role ${targetRole} assigned to ${targetUid}. User must sign out/in to refresh JWT.`);
      await refresh();
    } catch (e: any) { setErr(e.message); }
  }

  const refresh = useCallback(async () => {
    setLoading(true); setErr(null);
    try {
      const [h, a, t, ap, au] = await Promise.all([
        j<Health>("/api/health"),
        j<{ mode: string; data: AgentProfile[] }>("/api/agents"),
        j<{ mode: string; data: WorkItem[] }>("/api/tasks"),
        j<{ mode: string; data: Approval[] }>("/api/approvals"),
        j<{ mode: string; data: AuditEvent[] }>("/api/audit"),
      ]);
      setHealth(h);
      setAgents(a.data ?? []); setTasks(t.data ?? []);
      setApprovals(ap.data ?? []); setAudit(au.data ?? []);
      setModes({ agents: a.mode, tasks: t.mode, approvals: ap.mode, audit: au.mode });
    } catch (e: any) { setErr(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return agents.filter((a) => {
      if (div !== "all" && a.division !== div) return false;
      if (!s) return true;
      return [a.id, a.codename, a.role, a.division, ...(a.capabilities ?? [])].join(" ").toLowerCase().includes(s);
    });
  }, [agents, q, div]);

  const effectiveRole: ExecRole = verifiedRole ?? previewRole;
  const actorLabel = me?.authenticated ? `${me.email} (${verifiedRole}, via JWT)` : `preview:${previewRole} (unauthenticated — demo only)`;

  const kpi = useMemo(() => ({
    total: agents.length,
    active: agents.filter((a) => a.status === "active").length,
    pending: approvals.filter((a) => a.status === "pending").length,
    mine: approvals.filter((a) => a.status === "pending" && checkDecide({ actorRole: effectiveRole, actorId: me?.email ?? "preview", risk: a.risk, requestedBy: a.requested_by, status: a.status }).allowed).length,
    blocked: tasks.filter((t) => t.status === "blocked").length,
  }), [agents, approvals, tasks, effectiveRole, me]);

  async function decide(id: string, decision: "approved" | "rejected") {
    setActing(id + decision); setErr(null);
    try {
      const sb = browserSupabase();
      const { data } = await sb.auth.getSession();
      const token = data.session?.access_token;
      await j("/api/approvals", {
        method: "POST",
        headers: { "content-type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        // previewRole is ONLY used in demo/no-secret mode; live ignores it.
        body: JSON.stringify({ id, decision, previewRole }),
      });
      await refresh();
    } catch (e: any) { setErr(e.message); }
    finally { setActing(null); }
  }

  const live = health?.mode === "live";
  return (
    <main className="wrap">
      <div className="top">
        <div>
          <div className="eyebrow">NEAS AI WORKFORCE · OPERATIONAL CONTROL PLANE</div>
          <h1>CEO / CAIO Multi-Agent Operations</h1>
          <p className="sub">Role comes from the Supabase Auth JWT (<code className="k">app_metadata.exec_role</code> → <code className="k">profiles</code> fallback). The UI selector is preview-only; the server ignores it when live.</p>
        </div>
        <div className="row">
          <span className={`pill ${live ? "p-live" : "p-pending"}`}>{loading ? "checking…" : live ? "● LIVE" : "● " + (health?.mode ?? "unknown").toUpperCase().replace("-", " ")}</span>
          <button className="btn primary" onClick={refresh} disabled={loading}>↻ {loading ? "Refreshing…" : "Refresh live data"}</button>
        </div>
      </div>

      {/* Auth panel */}
      <div className="card" style={{ marginTop: 14 }}>
        {!me?.authenticated ? (
          <div>
            <b>Sign in with Supabase Auth</b> <span className="small mut">— decisions require a verified JWT when live. Unauthenticated approvals run in preview/demo only.</span>
            <div className="row" style={{ marginTop: 10 }}>
              <input placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} style={{ minWidth: 220 }} />
              <input placeholder="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              <button className="btn primary" disabled={authBusy} onClick={signIn}>Sign in</button>
              <button className="btn" disabled={authBusy} onClick={signUp}>Sign up</button>
              <span className="small mut">Preview as:</span>
              {(["CEO", "CAIO", "Operator"] as ExecRole[]).map((r) => (
                <button key={r} className={`tab ${previewRole === r ? "on" : ""}`} onClick={() => setPreviewRole(r)}>{r}</button>
              ))}
            </div>
          </div>
        ) : (
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div className="row">
              <span className="pill p-active">{me.role} · JWT verified ({me.source})</span>
              <span className="small"><b>{me.email}</b> <span className="mut">· {roleBlurb(me.role as ExecRole)}</span></span>
              <button className="btn" onClick={signOut}>Sign out</button>
            </div>
            {me.role === "CEO" && (
              <div className="row">
                <input placeholder="target user UUID" value={targetUid} onChange={(e) => setTargetUid(e.target.value)} style={{ minWidth: 260 }} />
                <select value={targetRole} onChange={(e) => setTargetRole(e.target.value as ExecRole)}><option>CEO</option><option>CAIO</option><option>Operator</option></select>
                <button className="btn primary" onClick={assignRole}>Assign role</button>
              </div>
            )}
          </div>
        )}
        <p className="small mut" style={{ margin: "8px 0 0" }}>First-time setup: createCEO account → SQL Editor: <code className="k">update auth.users set raw_app_meta_data = raw_app_meta_data || {`'{"exec_role":"CEO"}'`} where email='you@company.com'</code> → sign out/in. Or run <code className="k">supabase/migration-auth.sql</code> bootstrap block.</p>
      </div>

      {err && <section className="banner bad"><h3>⛔ Action blocked</h3><p>{err}</p></section>}

      {!loading && health && health.mode !== "live" && (
        <section className="banner">
          <h3>⚠ Control plane connection required — {health.checks.secretPresent ? "key present, query failing" : "SUPABASE_SECRET_KEY is not configured in the Vercel server environment"}</h3>
          <p>{health.guidance}</p>
        </section>
      )}

      <div className="grid kpi">
        <div className="card kpi"><div className="l">Agents</div><div className="n">{kpi.total}</div><div className="small mut">{kpi.active} active</div></div>
        <div className="card kpi"><div className="l">Pending approvals</div><div className="n">{kpi.pending}</div><div className="small mut">{kpi.mine} actionable by {effectiveRole}{me?.authenticated ? " (JWT)" : " (preview)"}</div></div>
        <div className="card kpi"><div className="l">Blocked work</div><div className="n">{kpi.blocked}</div><div className="small mut">needs attention</div></div>
        <div className="card kpi"><div className="l">Audit events</div><div className="n">{audit.length}</div><div className="small mut">incl. denied attempts</div></div>
      </div>

      <div className="tabs">
        {(["directory", "queue", "approvals", "audit"] as Tab[]).map((t) => (
          <button key={t} className={`tab ${tab === t ? "on" : ""}`} onClick={() => setTab(t)}>{t === "directory" ? `Directory (${filtered.length})` : t === "queue" ? `Work Queue (${tasks.length})` : t === "approvals" ? `Approvals (${kpi.pending})` : `Audit (${audit.length})`}</button>
        ))}
      </div>

      {tab === "directory" && (
        <div className="card" style={{ marginTop: 12 }}>
          <div className="row" style={{ marginBottom: 10 }}>
            <input placeholder="Search id, codename, capability…" value={q} onChange={(e) => setQ(e.target.value)} style={{ minWidth: 260 }} />
            <select value={div} onChange={(e) => setDiv(e.target.value)}>
              <option value="all">All divisions</option><option>CEO Office</option><option>CAIO Office</option><option>Operations</option><option>Intelligence</option><option>Autonomy</option>
            </select>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table><thead><tr><th>ID</th><th>Agent</th><th>Division</th><th>Capabilities</th><th>Status</th><th>Autonomy</th><th>Load</th></tr></thead>
              <tbody>{filtered.slice(0, 60).map((a) => (
                <tr key={a.id}><td><code className="k">{a.id}</code></td><td><b>{a.codename}</b><div className="small mut">{a.role}</div></td><td>{a.division}</td>
                  <td className="small">{(a.capabilities ?? []).join(" · ")}</td>
                  <td><span className={`pill p-${a.status}`}>{a.status}</span></td>
                  <td>L{a.autonomy_level}</td><td>{a.current_load}%</td></tr>
              ))}</tbody></table>
          </div>
        </div>
      )}

      {tab === "queue" && (
        <div className="card" style={{ marginTop: 12 }}>
          <table><thead><tr><th>Item</th><th>Owner</th><th>Priority</th><th>Status</th><th>Progress</th></tr></thead>
            <tbody>{tasks.map((t) => (
              <tr key={t.id}><td><b>{t.title}</b><div className="small mut">{t.id} · ETA {new Date(t.eta).toLocaleString()}</div></td>
                <td><code className="k">{t.owner_agent}</code></td><td><span className={`pill p-${t.priority}`}>{t.priority}</span></td>
                <td><span className={`pill p-${t.status}`}>{t.status.replace("_", " ")}</span></td><td>{t.progress}%</td></tr>
            ))}</tbody></table>
        </div>
      )}

      {tab === "approvals" && (
        <>
          <p className="small mut" style={{ marginTop: 10 }}>Acting as {actorLabel} · low/medium/high → CEO or CAIO · critical → CEO only · denials audit-logged.</p>
          <div className="grid two" style={{ marginTop: 8 }}>
            {approvals.map((a) => {
              const chk = checkDecide({ actorRole: effectiveRole, actorId: me?.email ?? "preview", risk: a.risk, requestedBy: a.requested_by, status: a.status });
              const needsAuth = live && !me?.authenticated;
              return (
                <div className="card" key={a.id}>
                  <div className="row" style={{ justifyContent: "space-between" }}>
                    <span className={`pill p-${a.risk}`}>{a.risk} risk · {a.risk === "critical" ? "CEO only" : "CEO/CAIO"}</span>
                    <span className={`pill p-${a.status}`}>{a.status}</span>
                  </div>
                  <h3 style={{ margin: "10px 0 4px" }}>{a.subject}</h3>
                  <p className="small mut" style={{ margin: 0 }}>{a.id} · requested by {a.requested_by} · {new Date(a.created_at).toLocaleString()}</p>
                  <p className="small">{a.detail}</p>
                  {a.decided_by && <p className="small mut">Decided by {a.decided_by}{a.decided_by_role ? ` (${a.decided_by_role})` : ""}.</p>}
                  {a.status === "pending" && (
                    <>
                      <div className="row">
                        <button className="btn primary" disabled={!chk.allowed || needsAuth || !!acting} title={needsAuth ? "Sign in required for live decisions." : chk.reason} onClick={() => decide(a.id, "approved")}>Approve</button>
                        <button className="btn" disabled={!chk.allowed || needsAuth || !!acting} title={needsAuth ? "Sign in required for live decisions." : chk.reason} onClick={() => decide(a.id, "rejected")}>Reject</button>
                      </div>
                      {needsAuth && <p className="small" style={{ color: "#fcd34d" }}>🔐 Sign in to decide — live mode requires a verified JWT.</p>}
                      {!needsAuth && !chk.allowed && <p className="small" style={{ color: "#fda4af" }}>🔒 {chk.reason} You are {effectiveRole}{me?.authenticated ? " (JWT)" : " (preview)"}.</p>}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      {tab === "audit" && (
        <div className="card" style={{ marginTop: 12 }}>
          <div className="timeline">{audit.map((e) => (
            <div className="ev" key={e.id}><span className="mut small">{new Date(e.at).toLocaleString()}</span>
              <span><b>{e.actor}</b>{(e as any).actor_role ? ` (${(e as any).actor_role})` : ""} · {e.action} → <code className="k">{e.target}</code> <span className="mut small">{e.hash}</span></span></div>
          ))}</div>
        </div>
      )}
    </main>
  );
}

-- RBAC hardening: required approver tier + decision attribution + denial audit.
alter table approvals add column if not exists required_role text not null default 'CEO or CAIO';
alter table approvals add column if not exists decided_by_role text;
alter table approvals add column if not exists decision_reason text;
alter table audit_log add column if not exists actor_role text;

-- Backfill required_role from risk tier (critical = CEO only).
update approvals set required_role = case when risk = 'critical' then 'CEO only' else 'CEO or CAIO' end
where required_role is null or required_role = '';

-- Keep future inserts consistent.
create or replace function set_required_role() returns trigger as $$
begin
  if new.required_role is null or new.required_role = '' or new.required_role = 'CEO or CAIO' then
    new.required_role := case when new.risk = 'critical' then 'CEO only' else 'CEO or CAIO' end;
  end if;
  return new;
end; $$ language plpgsql;

drop trigger if exists trg_set_required_role on approvals;
create trigger trg_set_required_role before insert or update of risk on approvals
for each row execute function set_required_role();

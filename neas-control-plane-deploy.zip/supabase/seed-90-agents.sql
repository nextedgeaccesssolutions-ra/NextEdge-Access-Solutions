-- Generates exactly 90 deterministic agent profiles (NEAS-001 … NEAS-090).
insert into agents (id, codename, role, division, capabilities, status, autonomy_level, current_load)
select
  'NEAS-' || lpad(g::text, 3, '0'),
  (array['Strategist','Orchestrator','Analyst','Operator','Guardian','Scout','Synthesizer','Auditor','Planner','Executor'])[1 + (g % 10)] || '-' || lpad(g::text, 2, '0'),
  (array['Strategist','Orchestrator','Analyst','Operator','Guardian','Scout','Synthesizer','Auditor','Planner','Executor'])[1 + (g % 10)],
  (array['CEO Office','CAIO Office','Operations','Intelligence','Autonomy'])[1 + (g % 5)],
  array[
    (array['planning','research','triage','forecasting','compliance','routing','summarization','verification','scheduling','escalation'])[1 + (g % 10)],
    (array['planning','research','triage','forecasting','compliance','routing','summarization','verification','scheduling','escalation'])[1 + ((g + 3) % 10)],
    (array['planning','research','triage','forecasting','compliance','routing','summarization','verification','scheduling','escalation'])[1 + ((g + 6) % 10)]
  ],
  (array['active','active','active','standby','training','offline'])[1 + (g % 6)],
  1 + (g % 5),
  (g * 37) % 100
from generate_series(1, 90) g
on conflict (id) do update set
  codename = excluded.codename, role = excluded.role, division = excluded.division,
  capabilities = excluded.capabilities, status = excluded.status,
  autonomy_level = excluded.autonomy_level, current_load = excluded.current_load,
  last_heartbeat = now();

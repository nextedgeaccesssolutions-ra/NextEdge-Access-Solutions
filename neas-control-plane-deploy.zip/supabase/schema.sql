-- NEAS AI WORKFORCE · Control Plane schema (idempotent)
create table if not exists agents (
  id text primary key,
  codename text not null,
  role text not null,
  division text not null default 'Operations',
  capabilities text[] not null default '{}',
  status text not null default 'standby' check (status in ('active','standby','training','offline')),
  autonomy_level int not null default 1 check (autonomy_level between 1 and 5),
  current_load int not null default 0,
  last_heartbeat timestamptz not null default now()
);

create table if not exists work_queue (
  id text primary key,
  title text not null,
  owner_agent text references agents(id),
  priority text not null default 'P2' check (priority in ('P0','P1','P2','P3')),
  status text not null default 'queued' check (status in ('queued','in_progress','blocked','done')),
  eta timestamptz,
  progress int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists approvals (
  id text primary key,
  subject text not null,
  requested_by text not null,
  risk text not null default 'medium' check (risk in ('low','medium','high','critical')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  detail text default '',
  created_at timestamptz not null default now(),
  decided_by text,
  decided_at timestamptz
);

create table if not exists audit_log (
  id generated always as identity primary key,
  at timestamptz not null default now(),
  actor text not null,
  action text not null,
  target text not null,
  hash text default ''
);

alter table agents enable row level security;
alter table work_queue enable row level security;
alter table approvals enable row level security;
alter table audit_log enable row level security;

-- Read: anon can read directory + queue (adjust to your policy).
-- Writes: service-role only (bypasses RLS), so no write policies needed.
drop policy if exists "public read agents" on agents;
create policy "public read agents" on agents for select to anon, authenticated using (true);
drop policy if exists "public read queue" on work_queue;
create policy "public read queue" on work_queue for select to anon, authenticated using (true);
drop policy if exists "public read approvals" on approvals;
create policy "public read approvals" on approvals for select to anon, authenticated using (true);
drop policy if exists "public read audit" on audit_log;
create policy "public read audit" on audit_log for select to anon, authenticated using (true);

-- Supabase Auth → exec_role wiring. JWT app_metadata is authoritative; profiles is fallback/auditable mirror.
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  exec_role text not null default 'Operator' check (exec_role in ('CEO','CAIO','Operator')),
  display_name text,
  created_at timestamptz not null default now()
);
alter table profiles enable row level security;
drop policy if exists "users read own profile" on profiles;
create policy "users read own profile" on profiles for select to authenticated using (auth.uid() = id);
-- Writes via service-role only (admin API / triggers). No public insert/update policy.

-- Ensure RBAC columns exist (safe if migration-rbac already ran).
alter table approvals add column if not exists decided_by_role text;
alter table approvals add column if not exists decision_reason text;
alter table approvals add column if not exists required_role text not null default 'CEO or CAIO';
alter table audit_log add column if not exists actor_role text;

-- First user bootstrap helper: run manually in SQL editor to make yourself CEO
-- (replace with your auth user id from Authentication → Users):
--   update auth.users set raw_app_meta_data = raw_app_meta_data || '{"exec_role":"CEO"}' where id = 'YOUR-UUID';
--   insert into profiles (id, exec_role, display_name) values ('YOUR-UUID','CEO','CEO')
--   on conflict (id) do update set exec_role='CEO';

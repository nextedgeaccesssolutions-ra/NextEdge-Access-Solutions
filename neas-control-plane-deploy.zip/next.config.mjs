/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  experimental: {
    serverActions: { bodySizeLimit: "1mb" }
  },
  // Never expose server secrets to the client. Block accidental NEXT_PUBLIC leak.
  env: {}
};

export default nextConfig;

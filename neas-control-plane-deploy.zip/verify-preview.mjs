// Usage: PREVIEW_URL=https://xxx.vercel.app node verify-preview.mjs
// Checks /api/health + /api/agents + /api/auth/me (unauth) without secrets.
const base = (process.env.PREVIEW_URL || "").replace(/\/$/, "");
if (!base) { console.error("Set PREVIEW_URL=https://<preview>.vercel.app"); process.exit(1); }
async function check(path, opts) {
  const r = await fetch(base + path, opts);
  const body = await r.json().catch(() => ({}));
  console.log(`\n${opts?.method || "GET"} ${path} -> ${r.status}`);
  console.log(JSON.stringify(body, null, 2).slice(0, 2000));
  return { status: r.status, body };
}
const h = await check("/api/health");
await check("/api/agents");
await check("/api/auth/me");
if (h.body?.mode === "live") console.log("\n✅ LIVE: Supabase connected.");
else {
  console.log(`\n⚠️ mode=${h.body?.mode} — fix per guidance:`);
  console.log(h.body?.guidance);
  if (!h.body?.checks?.secretPresent) console.log("→ Add SUPABASE_SECRET_KEY to Preview env + Redeploy.");
}

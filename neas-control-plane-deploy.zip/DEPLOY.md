# Deploy to Vercel Preview + verify live Supabase

## 1. Push this folder to GitHub (or `vercel` CLI)
```bash
git init && git add -A && git commit -m "control plane"
gh repo create neas-control-plane --private --source=. --push
```
Vercel → Add New Project → Import `neas-control-plane` → Framework: Next.js → Deploy (Preview).

## 2. Env (Project → Settings → Environment Variables)
| Var | Value | Envs |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://<ref>.supabase.co` | Preview (+Production) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | anon public key | Preview (+Production) |
| `SUPABASE_SECRET_KEY` | service_role / secret key | **Preview** (+Production), server-only |

Never add `NEXT_PUBLIC_SUPABASE_SECRET_KEY`. After saving → Deployments → Redeploy the Preview.

## 3. Supabase SQL (SQL Editor, in order)
1. `supabase/schema.sql` 2. `supabase/migration-rbac.sql` 3. `supabase/migration-auth.sql` 4. `supabase/seed-90-agents.sql`

## 4. Verify
```bash
PREVIEW_URL=https://<preview>.vercel.app node verify-preview.mjs
```
Expect `mode: live`, `agentsCount: 90`, `/api/agents mode: live`.
Then in UI: sign up → set yourself CEO via SQL bootstrap → sign out/in → `Approvals` shows `JWT verified`.
